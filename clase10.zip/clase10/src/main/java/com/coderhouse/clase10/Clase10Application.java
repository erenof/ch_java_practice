package com.coderhouse.clase10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase10Application {

	public static void main(String[] args) {
		SpringApplication.run(Clase10Application.class, args);
	}

}
